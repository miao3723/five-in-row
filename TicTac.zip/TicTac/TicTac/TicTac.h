
// TicTac.h : TicTac Ӧ�ó������ͷ�ļ�
//

#define EX 1
#define OH 2

#include "resource.h"       // ������


// CTicTacApp:
// �йش����ʵ�֣������ TicTac.cpp
//

class CMyApp : public CWinApp
{
public:
	virtual BOOL InitInstance();
	
};

class CMainWindow :public CWnd {
protected:
	static const int n = 361;
	CRect m_rcSquares[n];
	int m_nGameGrid[n];
	int m_nNextChar;
	int GetRectID(CPoint point);
	void DrawBoard(CDC* pDC);
	void DrawBlack(CDC* pDC,int nPos);
	void DrawWhite(CDC* pDC,int nPos);
	void ResetGame();
	void CheckForGameOver(int thischar,int ID);
	void set_m_rcSquares();
	int IsWinner(int thisChar,int ID);
	BOOL IsDraw();
public:
	CMainWindow();
protected:
	virtual void PostNcDestroy();

	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	
	DECLARE_MESSAGE_MAP()
};
