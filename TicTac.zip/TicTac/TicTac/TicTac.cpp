
// TicTac.cpp : ����Ӧ�ó��������Ϊ��
//

#include "stdafx.h"
#include "afxwinappex.h"
#include "afxdialogex.h"
#include "TicTac.h"
#include "MainFrm.h"
#include "Math.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CMyApp myApp;

BOOL CMyApp::InitInstance() {
	m_pMainWnd = new CMainWindow;
	m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}

BEGIN_MESSAGE_MAP(CMainWindow,CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_CLOSE()
END_MESSAGE_MAP()


void CMainWindow::set_m_rcSquares() {
	int i = 0, k = 0;
	while (i < sqrt(n)) {
		int j = 0;
		while (j <sqrt(n)) {
			m_rcSquares[k] = CRect(25+50 * j,25+50* i, 25+50* (j+1),25+50* (i+1));
			j = j + 1;
			k = k + 1;
		}
		i = i + 1;
	}
	
}

CMainWindow::CMainWindow() {
	
	set_m_rcSquares();
	m_nNextChar = EX;
	::ZeroMemory(m_nGameGrid,n*sizeof(int));

	CString strWndClass = AfxRegisterWndClass(
		CS_DBLCLKS,
		AfxGetApp()->LoadStandardCursor(IDC_ARROW),
		(HBRUSH)(COLOR_3DFACE+1),
		AfxGetApp()->LoadStandardIcon(IDI_WINLOGO)
	);


	CreateEx(0,strWndClass,_T("Tic-Tac-Toe"),
		WS_OVERLAPPED|WS_SYSMENU|WS_CAPTION|WS_MINIMIZEBOX,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,NULL
	);

	CRect rect(0,0,1000,1000);
	CalcWindowRect(&rect);
	SetWindowPos(NULL, 0, 0, rect.Width(), rect.Height(),
		SWP_NOZORDER | SWP_NOMOVE | SWP_NOREDRAW);
}

void CMainWindow::PostNcDestroy() {
	delete this;
}

void CMainWindow::OnPaint() {
	CPaintDC dc(this);
	DrawBoard(&dc);
}

void CMainWindow::OnLButtonDown(UINT nFlags,CPoint point) {
	if (m_nNextChar != EX)
		return;
	int nPos = GetRectID(point);
	if ((nPos == -1) || (m_nGameGrid[nPos] != 0))
		return;

	m_nGameGrid[nPos] = EX;
	m_nNextChar = OH;

	CClientDC dc(this);
	DrawBlack(&dc,nPos);
	CheckForGameOver(EX,nPos);
}

void CMainWindow::OnRButtonDown(UINT nFlags, CPoint point) {
	if (m_nNextChar != OH)
		return;
	int nPos = GetRectID(point);
	if ((nPos == -1) || (m_nGameGrid[nPos] != 0))
		return;

	m_nGameGrid[nPos] = OH;
	m_nNextChar = EX;

	CClientDC dc(this);
	DrawWhite(&dc, nPos);
	CheckForGameOver(OH,nPos);
}

void CMainWindow::OnLButtonDblClk(UINT nFlags,CPoint point) {
	CClientDC dc(this);
	if (dc.GetPixel(point) == RGB(0, 0, 0))
		ResetGame();
}

int CMainWindow::GetRectID(CPoint point) {
	for (int i = 0; i < n; i++) {
		if (m_rcSquares[i].PtInRect(point))
			return i;
	}
	return -1;
}

void CMainWindow::DrawBoard(CDC* pDC) {
	CPen pen(PS_SOLID, 5, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);
	int i = 0;
	int nsqure = sqrt(n);
	while (i < sqrt(n)) {
		
			pDC->MoveTo(50*(i+1),0);
			pDC->LineTo(50*(i+1), 50*(nsqure+1));
			i = i + 1;
	}
	i = 0;
	
	while (i < sqrt(n)) {

		pDC->MoveTo(0,50*(i+1));
		pDC->LineTo(50*(sqrt(n)+1),50*(i+1));
		i = i + 1;
	}

	for (int i = 0; i < n;i++) {
		if (m_nGameGrid[i] == EX)
			DrawBlack(pDC, i);
		else if (m_nGameGrid[i] == OH)
			DrawWhite(pDC,i);
	}
	pDC->SelectObject(pOldPen);
}

void CMainWindow::DrawBlack(CDC* pDC, int nPos) {
	CPen pen(PS_SOLID, 16, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);
	pDC->SelectStockObject(NULL_BRUSH);
	CRect rect = m_rcSquares[nPos];
	rect.DeflateRect(16, 16);
	pDC->Ellipse(rect);
	pDC->SelectObject(pOldPen);

}

void CMainWindow::DrawWhite(CDC* pDC, int nPos) {
	CPen pen(PS_SOLID, 16, RGB(255, 255, 255));
	CPen* pOldPen = pDC->SelectObject(&pen);
	pDC->SelectStockObject(NULL_BRUSH);
	CRect rect = m_rcSquares[nPos];
	rect.DeflateRect(16, 16);
	pDC->Ellipse(rect);
	pDC->SelectObject(pOldPen);
}

void CMainWindow::CheckForGameOver(int thisChar,int ID) {
	int nWinner;
	if (nWinner=IsWinner(thisChar,ID)) {
		CString string = (nWinner == EX) ? _T("Black wins!") : _T("White wins!");
		MessageBox(string, _T("Game over"),MB_ICONEXCLAMATION|MB_OK);
		ResetGame();
	}
	else if (IsDraw()) {
		MessageBox(_T("It's a draw!"), _T("Game Over"), MB_ICONEXCLAMATION | MB_OK);
		ResetGame();

	}
}

int CMainWindow::IsWinner(int thisChar,int ID) {
	int nsquare = sqrt(n);
	int upDown = 1,leftRight=1,leftDown=1,rightUp=1;
	int nPos = ID - nsquare;
	while ((nPos>= 0)&& (m_nGameGrid[nPos] == thisChar)) {
		upDown++;
		if (upDown == 5)return thisChar;
		nPos = nPos - nsquare;
	}
	nPos = ID + nsquare;
	while ((nPos <= n-1) && (m_nGameGrid[nPos] == thisChar)) {
		upDown++;
		if (upDown == 5)return thisChar;
		nPos = nPos + nsquare;
	}
	nPos = ID - nsquare +1;
	while ((nPos >=0) &&nPos%nsquare !=0&& (m_nGameGrid[nPos] == thisChar)) {
		rightUp++;
		if (rightUp == 5)return thisChar;
		nPos = nPos - nsquare +1;
	}
	nPos = ID + nsquare - 1;
	while ((nPos <= n-1) &&nPos%nsquare !=nsquare-1&& (m_nGameGrid[nPos] == thisChar)) {
		rightUp++;
		if (rightUp == 5)return thisChar;
		nPos = nPos + nsquare - 1;
	}

	nPos = ID - nsquare -1 ;
	while ((nPos >= 0) &&nPos%nsquare!=nsquare-1&& (m_nGameGrid[nPos] == thisChar)) {
		leftDown++;
		if (leftDown == 5)return thisChar;
		nPos = nPos - nsquare -1;
	}
	nPos = ID + nsquare +1;
	while ((nPos <= n-1) && nPos % nsquare != 0&& (m_nGameGrid[nPos] == thisChar)) {
		leftDown++;
		if (leftDown == 5)return thisChar;
		nPos = nPos + nsquare + 1;
	}

	nPos = ID - 1;
	while ((nPos >= 0) && nPos % nsquare != nsquare - 1 && (m_nGameGrid[nPos] == thisChar)) {
		leftRight++;
		if (leftRight == 5)return thisChar;
		nPos = nPos-1;
	}
	nPos = ID+ 1;
	while ((nPos <= n-1) && nPos % nsquare != 0&& (m_nGameGrid[nPos] == thisChar)) {
		leftRight++;
		if (leftRight == 5)return thisChar;
		nPos = nPos + 1;
	}
	
	return 0;
}

BOOL CMainWindow::IsDraw() {
	for (int i = 0; i < n; i++) {
		if (m_nGameGrid[i] == 0)
			return FALSE;
	}
	return TRUE;
}

void CMainWindow::ResetGame() {
	m_nNextChar = EX;
	::ZeroMemory(m_nGameGrid, n * sizeof(int));
	Invalidate();
}

void CMainWindow::OnClose() {
	int _temp;
	_temp = MessageBox(_T("You will quit the game!Are you sure?"), _T("Message Box"), MB_OKCANCEL);
	if (_temp == IDOK) DestroyWindow();

}